# Asistente Virtual - Municipalidad de San Martín

Estructura completa del proyecto con frontend, backend y panel de operador.